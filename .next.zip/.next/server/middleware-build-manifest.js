globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/05be8470af537e1f.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/f2f58a7e93290fbb.js",
    "static/chunks/38eb66a58ed5ffd7.js",
    "static/chunks/turbopack-62fad9ec49082fb8.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];