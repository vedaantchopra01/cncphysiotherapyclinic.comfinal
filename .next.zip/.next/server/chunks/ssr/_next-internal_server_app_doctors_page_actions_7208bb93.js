module.exports=[74943,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_doctors_page_actions_7208bb93.js.map