module.exports=[5497,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_book-appointment_page_actions_aac3b320.js.map